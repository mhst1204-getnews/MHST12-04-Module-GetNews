<?php

/**
 * @Project NUKEVIET 3.0
 * @Author VINADES.,JSC (contact@vinades.vn)
 * @Copyright (C) 2010 VINADES.,JSC. All rights reserved
 * @Createdate Mon, 23 Jul 2012 02:56:18 GMT
 */

if ( ! defined( 'NV_MAINFILE' ) ) die( 'Stop!!!' );

$module_version = array( //
		"name" => "Getnews", //
		"modfuncs" => "main,detail,search", //
		"submenu" => "main,detail,search", //
		"is_sysmod" => 0, //
		"virtual" => 1, //
		"version" => "1.0.0", //
		"date" => "Mon, 23 Jul 2012 02:56:18 GMT", //
		"author" => "VINADES (contact@vinades.vn)", //
		"uploads_dir" => array($module_name), //
		"note" => "" //
	);

?>